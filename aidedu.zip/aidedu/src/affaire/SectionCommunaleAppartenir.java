package affaire;

public class SectionCommunaleAppartenir extends Commune {
	private int idSectionCommunaleAppartenir;
	private String nomSectionCommunale;
	private String nomCommune;
	
	public int getIdSectionCommunaleAppartenir() {
		return idSectionCommunaleAppartenir;
	}
	public void setIdSectionCommunaleAppartenir(int idSectionCommunaleAppartenir) {
		this.idSectionCommunaleAppartenir = idSectionCommunaleAppartenir;
	}
	public String getNomSectionCommunale() {
		return nomSectionCommunale;
	}
	public void setNomSectionCommunale(String nomSectionCommunale) {
		this.nomSectionCommunale = nomSectionCommunale;
	}
	public String getNomCommune() {
		return nomCommune;
	}
	public void setNomCommune(String nomCommune) {
		this.nomCommune = nomCommune;
	}
	public SectionCommunaleAppartenir() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SectionCommunaleAppartenir(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public SectionCommunaleAppartenir(String nomSectionCommunale, String nomCommune) {
		super();
		this.nomSectionCommunale = nomSectionCommunale;
		this.nomCommune = nomCommune;
	}
	
	

}
