package affaire;

import java.io.InputStream;

public class Classe extends Institution {
	private String nomClasse;

	public String getNomClasse() {
		return nomClasse;
	}

	public void setNomClasse(String nomClasse) {
		this.nomClasse = nomClasse;
	}

	public Classe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Classe(String matriculeInstitut, String nomInstitut, String acronyme, String nomUtilisateur, String motPasse,
			String emailInstitut, String dateFondation, String telephone, String cycleInstitut,
			String typeInstitut, InputStream fichier, boolean valid) {
		super(matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, motPasse, emailInstitut, dateFondation, telephone, cycleInstitut, typeInstitut, fichier, valid);
		// TODO Auto-generated constructor stub
	}

	public Classe(String codePostalSectionCommunale, String nomSectionCommunale) {
		super(codePostalSectionCommunale, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}



	public Classe(String nomClasse) {
		super();
		this.nomClasse = nomClasse;
	}

	
	

}
