package affaire;

import java.io.InputStream;


public class EleveEtreEprouve extends Matiere {
	private Long idEleveEtreEprouve;
	private Long idEleveSInscrire;
	private String numIdentite;
	private String anneeAcademique;
	private String nomClasse;
	private String codeMatiere;
	private Double note;
	
	public Long getIdEleveEtreEprouve() {
		return idEleveEtreEprouve;
	}
	public void setIdEleveEtreEprouve(Long idEleveEtreEprouve) {
		this.idEleveEtreEprouve = idEleveEtreEprouve;
	}
	public Long getIdEleveSInscrire() {
		return idEleveSInscrire;
	}
	public void setIdEleveSInscrire(Long idEleveSInscrire) {
		this.idEleveSInscrire = idEleveSInscrire;
	}
	public String getNumIdentite() {
		return numIdentite;
	}
	public void setNumIdentite(String numIdentite) {
		this.numIdentite = numIdentite;
	}
	public String getAnneeAcademique() {
		return anneeAcademique;
	}
	public void setAnneeAcademique(String anneeAcademique) {
		this.anneeAcademique = anneeAcademique;
	}
	public String getNomClasse() {
		return nomClasse;
	}
	public void setNomClasse(String nomClasse) {
		this.nomClasse = nomClasse;
	}
	public String getCodeMatiere() {
		return codeMatiere;
	}
	public void setCodeMatiere(String codeMatiere) {
		this.codeMatiere = codeMatiere;
	}
	public Double getNote() {
		return note;
	}
	public void setNote(Double note) {
		this.note = note;
	}
	public EleveEtreEprouve() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EleveEtreEprouve(String codeMatiere, String libelle, int base, String nomClasse, int statut) {
		super(codeMatiere, libelle, base, nomClasse, statut);
		// TODO Auto-generated constructor stub
	}
	public EleveEtreEprouve(String matriculeInstitut, String nomInstitut, String acronyme, String nomUtilisateur,
			String motPasse, String emailInstitut, String dateFondation, String telephone, String cycleInstitut,
			String typeInstitut, InputStream fichier, boolean valid) {
		super(matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, motPasse, emailInstitut, dateFondation, telephone,
				cycleInstitut, typeInstitut, fichier, valid);
		// TODO Auto-generated constructor stub
	}
	public EleveEtreEprouve(String codePostalSectionCommunale, String nomSectionCommunale) {
		super(codePostalSectionCommunale, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}
	public EleveEtreEprouve(String nomClasse) {
		super(nomClasse);
		// TODO Auto-generated constructor stub
	}
	public EleveEtreEprouve(Long idEleveSInscrire, String numIdentite, String anneeAcademique, String nomClasse,
			String codeMatiere, Double note) {
		super();
		this.idEleveSInscrire = idEleveSInscrire;
		this.numIdentite = numIdentite;
		this.anneeAcademique = anneeAcademique;
		this.nomClasse = nomClasse;
		this.codeMatiere = codeMatiere;
		this.note = note;
	}
	
	
}
