package affaire;

import java.util.List;

public interface IOperation {
	// Interfaces pour Eleves

	public void add(Eleve el);
	public static Eleve login(Eleve eleve) {
		return null;
	}
	
	
	
	// Interfaces pour Institutions
	public void add(Institution inst);
	public static Institution login(Institution institution) {
		return null;
	}
	public List<Eleve> dernierEleve();
	public void add(EleveEtreEprouve eleveprouv);
	public List<EleveEtreEprouve> eleveEprouve(Long id);
	public List<EleveEtreEprouve> eleveEprouve(String numId);
	public void updateEleve(Eleve el);
	public void add(EleveSInscrire ele);
	public List<EleveEtreEprouve> derniereNote();
	public List<EleveSInscrire> dernierInscrit();
	
	
	
	
	// Interfaces pour Personnels
	public static Personnel login(Personnel personnel) {
		return null;
	}
	public List<Eleve> listEleves();
	public List<Eleve> elevesParMC(String mc);
	public List<Eleve> getEleve(String numId);
	public Eleve trouverEleve(String numId);
	public List<EleveSInscrire> elevesParInstitut(String numId);
	
	
	public void add(InstitutionSeTrouver instrouv);
	public List<Institution> listInstitutions();
	public List<Institution> institutionsParMC(String moc);
	public List<Institution> getInstitution(String matricu);
	public void updateInstitution(Institution inst);
	public List<Institution> institutionParSection(String nomSect);
	public List<Institution> derniereInstitution();
	public List<InstitutionSeTrouver> derniereLocalisation();
	
}
