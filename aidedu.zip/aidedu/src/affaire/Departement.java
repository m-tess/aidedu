package affaire;

public class Departement {
	private String nomDepartement;
	
	public String getNomDepartement() {
		return nomDepartement;
	}
	public void setNomDepartement(String nomDepartement) {
		this.nomDepartement = nomDepartement;
	}
	public Departement() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Departement(String nomDepartement) {
		super();
		this.nomDepartement = nomDepartement;
	}
	
	

}
