package affaire;

import java.io.InputStream;


public class Matiere extends Classe {
	private String codeMatiere;
	private String libelle;
	public int base;
	private String nomClasse;
	private int statut;
	
	public String getCodeMatiere() {
		return codeMatiere;
	}
	public void setCodeMatiere(String codeMatiere) {
		this.codeMatiere = codeMatiere;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public int getBase() {
		return base;
	}
	public void setBase(int base) {
		this.base = base;
	}
	public String getNomClasse() {
		return nomClasse;
	}
	public void setNomClasse(String nomClasse) {
		this.nomClasse = nomClasse;
	}
	public int getStatut() {
		return statut;
	}
	public void setStatut(int statut) {
		this.statut = statut;
	}
	public Matiere() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Matiere(String matriculeInstitut, String nomInstitut, String acronyme, String nomUtilisateur,
			String motPasse, String emailInstitut, String dateFondation, String telephone, String cycleInstitut,
			String typeInstitut, InputStream fichier, boolean valid) {
		super(matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, motPasse, emailInstitut, dateFondation, telephone,
				cycleInstitut, typeInstitut, fichier, valid);
		// TODO Auto-generated constructor stub
	}
	public Matiere(String codePostalSectionCommunale, String nomSectionCommunale) {
		super(codePostalSectionCommunale, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}
	public Matiere(String nomClasse) {
		super(nomClasse);
		// TODO Auto-generated constructor stub
	}
	public Matiere(String codeMatiere, String libelle, int base, String nomClasse, int statut) {
		super();
		this.codeMatiere = codeMatiere;
		this.libelle = libelle;
		this.base = base;
		this.nomClasse = nomClasse;
		this.statut = statut;
	}
	
	
	
}
