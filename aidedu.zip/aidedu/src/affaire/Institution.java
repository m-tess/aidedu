package affaire;

import java.io.InputStream;

public class Institution extends SectionCommunale {
	private String matriculeInstitut;
	private String nomInstitut;
	private String acronyme;
	private String nomUtilisateur;
    private String motPasse;
	private String emailInstitut;
	private String dateFondation;
	private String telephone;
	private String cycleInstitut;
	private String typeInstitut;
	private InputStream fichier;
	public boolean valid;
	
	public String getMatriculeInstitut() {
		return matriculeInstitut;
	}
	public void setMatriculeInstitut(String matriculeInstitut) {
		this.matriculeInstitut = matriculeInstitut;
	}
	public String getNomInstitut() {
		return nomInstitut;
	}
	public void setNomInstitut(String nomInstitut) {
		this.nomInstitut = nomInstitut;
	}
	public String getAcronyme() {
		return acronyme;
	}
	public void setAcronyme(String acronyme) {
		this.acronyme = acronyme;
	}
	public String getNomUtilisateur() {
		return nomUtilisateur;
	}
	public void setNomUtilisateur(String nomUtilisateur) {
		this.nomUtilisateur = nomUtilisateur;
	}
	public String getMotPasse() {
		return motPasse;
	}
	public void setMotPasse(String motPasse) {
		this.motPasse = motPasse;
	}
	public String getEmailInstitut() {
		return emailInstitut;
	}
	public void setEmailInstitut(String emailInstitut) {
		this.emailInstitut = emailInstitut;
	}
	public String getDateFondation() {
		return dateFondation;
	}
	public void setDateFondation(String dateFondation) {
		this.dateFondation = dateFondation;
	}
	
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getCycleInstitut() {
		return cycleInstitut;
	}
	public void setCycleInstitut(String cycleInstitut) {
		this.cycleInstitut = cycleInstitut;
	}
	public String getTypeInstitut() {
		return typeInstitut;
	}
	public void setTypeInstitut(String typeInstitut) {
		this.typeInstitut = typeInstitut;
	}
	public InputStream getFichier() {
		return fichier;
	}
	public void setFichier(InputStream fichier) {
		this.fichier = fichier;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	public Institution() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Institution(String codePostalSectionCommunale, String nomSectionCommunale) {
		super(codePostalSectionCommunale, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}
	public Institution(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public Institution(String matriculeInstitut, String nomInstitut, String acronyme, String nomUtilisateur,
			String motPasse, String emailInstitut, String dateFondation, String telephone,
			String cycleInstitut, String typeInstitut, InputStream fichier, boolean valid) {
		super();
		this.matriculeInstitut = matriculeInstitut;
		this.nomInstitut = nomInstitut;
		this.acronyme = acronyme;
		this.nomUtilisateur = nomUtilisateur;
		this.motPasse = motPasse;
		this.emailInstitut = emailInstitut;
		this.dateFondation = dateFondation;
		this.telephone = telephone;
		this.cycleInstitut = cycleInstitut;
		this.typeInstitut = typeInstitut;
		this.fichier = fichier;
		this.valid = valid;
	}
	
	
	
}