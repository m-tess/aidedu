package affaire;

import java.io.InputStream;

public class InstitutionSeTrouver extends Institution {
	private Long idInstitutionSeTrouver;
	private String matriculeInstitut;
	private String nomInstitut;
	private String adresse;
	private String nomSectionCommunale;
	private String nomDepartement;
	
	public Long getIdInstitutionSeTrouver() {
		return idInstitutionSeTrouver;
	}
	public void setIdInstitutionSeTrouver(Long idInstitutionSeTrouver) {
		this.idInstitutionSeTrouver = idInstitutionSeTrouver;
	}
	public String getMatriculeInstitut() {
		return matriculeInstitut;
	}
	public void setMatriculeInstitut(String matriculeInstitut) {
		this.matriculeInstitut = matriculeInstitut;
	}
	public String getNomInstitut() {
		return nomInstitut;
	}
	public void setNomInstitut(String nomInstitut) {
		this.nomInstitut = nomInstitut;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getNomSectionCommunale() {
		return nomSectionCommunale;
	}
	public void setNomSectionCommunale(String nomSectionCommunale) {
		this.nomSectionCommunale = nomSectionCommunale;
	}
	public String getNomDepartement() {
		return nomDepartement;
	}
	public void setNomDepartement(String nomDepartement) {
		this.nomDepartement = nomDepartement;
	}
	public InstitutionSeTrouver() {
		super();
		// TODO Auto-generated constructor stub
	}
	public InstitutionSeTrouver(String matriculeInstitut, String nomInstitut, String acronyme, String nomUtilisateur,
			String motPasse, String emailInstitut, String dateFondation, String telephone, String cycleInstitut,
			String typeInstitut, InputStream fichier, boolean valid) {
		super(matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, motPasse, emailInstitut, dateFondation, telephone,
				cycleInstitut, typeInstitut, fichier, valid);
		// TODO Auto-generated constructor stub
	}
	public InstitutionSeTrouver(String codePostalSectionCommunale, String nomSectionCommunale) {
		super(codePostalSectionCommunale, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}
	public InstitutionSeTrouver(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public InstitutionSeTrouver(String matriculeInstitut, String nomInstitut, String adresse,
			String nomSectionCommunale, String nomDepartement) {
		super();
		this.matriculeInstitut = matriculeInstitut;
		this.nomInstitut = nomInstitut;
		this.adresse = adresse;
		this.nomSectionCommunale = nomSectionCommunale;
		this.nomDepartement = nomDepartement;
	}
	
	
	
}
