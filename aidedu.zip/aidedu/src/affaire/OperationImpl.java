package affaire;



import java.sql.*;
import java.util.*;



//import affaire.Personnel.Poste;

public class OperationImpl implements IOperation {
	private List<Eleve> eleves = null;
	private List<EleveSInscrire> eleve = null;
	private List<EleveEtreEprouve> elevep = null;
	private List<Institution> institutions = null;
	private List<InstitutionSeTrouver> institutrouv = null;
	static Connection currentCon = null;
	static ResultSet rs = null;  
	
//Eleve
	
	public static Eleve login(Eleve eleve) {
		
	      //preparing some objects for connection 
	      Statement stmt = null;    
		
	      String numIdentite = eleve.getNumIdentite();    
	      String motPass = eleve.getMotPass();
		    
	      String searchQuery = "select * from Eleve natural join EleveSInscrire where numIdentite='"+numIdentite+"' AND motPass='"+motPass+"'";		    
	   
	      // "System.out.println" prints in the console; Normally used to trace the process
	   System.out.println("Your user name is " +numIdentite);          
	   System.out.println("Your password is " +motPass);
	   System.out.println("Query: "+searchQuery);
		    
	   try 
	   {   //connect to db_AidEdu 
	      currentCon = ConnectionManager.getConnection();
	      stmt = currentCon.createStatement();
	      rs = stmt.executeQuery(searchQuery);	        
	      boolean more = rs.next();
		       
	      // if user does not exist set the isStatut variable to false
	      if (!more) 
	      {

	    	 System.out.println("Sorry, you are not a registered user! Please sign up first");
	         eleve.setValid(false);
	      } 
		        
	      //if user exists set the isStatut variable to true
	      else if (more) 
	      {
	    	  String emailEleve = rs.getString("emailEleve");
	    	  String nomEleve = rs.getString("nomEleve");
	    	  String prenomEleve = rs.getString("prenomEleve");
	    	  Long id = Long.parseLong(rs.getString("idEleveSInscrire"));  
  		     
	         System.out.println("Ton nom :" + nomEleve);
	         System.out.println("Ton prenom :" + prenomEleve);
	         System.out.println("Ton adresse de courrier :" + emailEleve);
	         System.out.println("Ton id d'inscription :" + id);
	         
	         eleve.setNomEleve(nomEleve);
	         eleve.setPrenomEleve(prenomEleve);
	         eleve.setEmailEleve(emailEleve);
	         eleve.setIdEleve(id);
	         
	         
	         eleve.setValid(true);
	      } 
	    } 
	   catch (Exception ex) 
	   {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 
		    
	   //some exception handling
	   finally 
	   {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (stmt != null) {
	         try {
	            stmt.close();
	         } catch (Exception e) {}
	            stmt = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	         }

	         currentCon = null;
	      }
	   }
	return eleve;
	}	
		
	
	@Override
	public void add(Eleve el) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement pr =null;
		try {	
			pr = conn.prepareStatement("Insert into Eleve values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			pr.setString(1, null);
			pr.setString(2, el.getNumIdentite());
			pr.setString(3, el.getMotPass());
			pr.setString(4, el.getNomEleve());
			pr.setString(5, el.getPrenomEleve());
			pr.setString(6, el.getSexeEleve());
			pr.setString(7, el.getDateNaissanceEleve());
			pr.setString(8, el.getNationaliteEleve());
			pr.setString(9, el.getEmailEleve());
			pr.setBinaryStream(10, el.getFichier1());
			pr.setBinaryStream(11, el.getFichier2());
            pr.setBoolean(12, el.isValid());
			pr.executeUpdate();
			pr.close();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(pr == null) {
			throw new RuntimeException("Veuillez saisir les informations obligatoires !");
		}else {
			throw new RuntimeException("Informations sauvegardées avec succès !");
		}
	}

	@Override
	public List<Eleve> getEleve(String numId){
		eleves = new ArrayList<Eleve>();
		Eleve elev =null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleve, numIdentite, motPass, nomEleve, prenomEleve, sexeEleve, dateNaissanceEleve, nationaliteEleve, emailEleve, valid from Eleve where numIdentite =?");
			ps.setString(1, numId);
		    ResultSet rs = ps.executeQuery();
		   
if(rs.next()) {
	elev = new Eleve();
	elev.setIdEleve(rs.getLong("idEleve"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setMotPass(rs.getString("motPass"));
	elev.setNomEleve(rs.getString("nomEleve"));
	elev.setPrenomEleve(rs.getString("prenomEleve"));
	elev.setSexeEleve(rs.getString("sexeEleve"));
	elev.setDateNaissanceEleve(rs.getString("dateNaissanceEleve"));
	elev.setNationaliteEleve(rs.getString("nationaliteEleve"));
	elev.setEmailEleve(rs.getString("emailEleve"));
	elev.setValid(rs.getBoolean("valid"));
	
    eleves.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(elev == null) throw new RuntimeException("Numéro Identité: '"+numId+"' introuvable. Vérifiez et réessayez!");
	return eleves;
    }

	
	@Override
	public List<Eleve> listEleves() {
		eleves = new ArrayList<Eleve>();
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Eleve");
		    ResultSet rs = ps.executeQuery();
		    
while(rs.next()) {
	Eleve elev = new Eleve();
	elev.setIdEleve(rs.getLong("idEleve"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setMotPass(rs.getString("motPass"));
	elev.setNomEleve(rs.getString("nomEleve"));
	elev.setPrenomEleve(rs.getString("prenomEleve"));
	elev.setSexeEleve(rs.getString("sexeEleve"));
	elev.setDateNaissanceEleve(rs.getString("dateNaissanceEleve"));
	elev.setNationaliteEleve(rs.getString("nationaliteEleve"));
	elev.setEmailEleve(rs.getString("emailEleve"));
    elev.setFichier1(rs.getBinaryStream("fichier1"));
    elev.setFichier2(rs.getBinaryStream("fichier2"));
	elev.setValid(rs.getBoolean("valid"));
	
	eleves.add(elev);
	}
    ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return eleves;
	}
	
	
	@Override
	public List<Eleve> dernierEleve() {
		eleves = new ArrayList<Eleve>();
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM Eleve order by idEleve desc limit 1");
		    ResultSet rs = ps.executeQuery();
		    
if(rs.next()) {
	Eleve elev = new Eleve();
	elev.setIdEleve(rs.getLong("idEleve"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setMotPass(rs.getString("motPass"));
	elev.setNomEleve(rs.getString("nomEleve"));
	elev.setPrenomEleve(rs.getString("prenomEleve"));
	elev.setSexeEleve(rs.getString("sexeEleve"));
	elev.setDateNaissanceEleve(rs.getString("dateNaissanceEleve"));
	elev.setNationaliteEleve(rs.getString("nationaliteEleve"));
	elev.setEmailEleve(rs.getString("emailEleve"));
    elev.setFichier1(rs.getBinaryStream("fichier1"));
    elev.setFichier2(rs.getBinaryStream("fichier2"));
	elev.setValid(rs.getBoolean("valid"));
	
	eleves.add(elev);
	}
    ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return eleves;
	}

	
	@Override
	public List<Eleve> elevesParMC(String mc) {
		eleves = new ArrayList<Eleve>();
		Eleve elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleve, numIdentite, motPass, nomEleve, prenomEleve, sexeEleve, dateNaissanceEleve, nationaliteEleve, emailEleve, valid from Eleve where concat(nomEleve, ' ', prenomEleve) like ?");
		    ps.setString(1, "%"+mc+"%");
			ResultSet rs = ps.executeQuery();
while(rs.next()) {
	elev = new Eleve();
	elev.setIdEleve(rs.getLong("idEleve"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setMotPass(rs.getString("motPass"));
	elev.setNomEleve(rs.getString("nomEleve"));
	elev.setPrenomEleve(rs.getString("prenomEleve"));
	elev.setSexeEleve(rs.getString("sexeEleve"));
	elev.setDateNaissanceEleve(rs.getString("dateNaissanceEleve"));
	elev.setNationaliteEleve(rs.getString("nationaliteEleve"));
	elev.setEmailEleve(rs.getString("emailEleve"));
	elev.setValid(rs.getBoolean("valid"));
	
	eleves.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		if(elev == null) throw new RuntimeException("Aucun nom et prénom contenant '"+mc+"' trouvé !");
		return eleves;
	}
    
	@Override
	public Eleve trouverEleve(String numId){
		Eleve elev =null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleve, numIdentite, motPass, nomEleve, prenomEleve, sexeEleve, dateNaissanceEleve, nationaliteEleve, emailEleve, valid from Eleve where numIdentite =?");
			ps.setString(1, numId);
		    ResultSet rs = ps.executeQuery();
		   
if(rs.next()) {
	elev = new Eleve();
	elev.setIdEleve(rs.getLong("idEleve"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setMotPass(rs.getString("motPass"));
	elev.setNomEleve(rs.getString("nomEleve"));
	elev.setPrenomEleve(rs.getString("prenomEleve"));
	elev.setSexeEleve(rs.getString("sexeEleve"));
	elev.setDateNaissanceEleve(rs.getString("dateNaissanceEleve"));
	elev.setNationaliteEleve(rs.getString("nationaliteEleve"));
	elev.setEmailEleve(rs.getString("emailEleve"));
	elev.setValid(rs.getBoolean("valid"));
	
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(elev == null) throw new RuntimeException("Numéro Identité: '"+numId+"' introuvable. Vérifiez et réessayez!");
	return elev;
    }
	
	
	@Override
	public void updateEleve(Eleve el) {
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement pr = conn.prepareStatement("update Eleve set nomEleve=?, prenomEleve=?, sexeEleve=?, dateNaissanceEleve=?, nationaliteEleve=?, emailEleve=?, fichier1=?, fichier2=?, valid=? where numIdentite=?");
			pr.setString(1, el.getNomEleve());
			pr.setString(2, el.getPrenomEleve());
			pr.setString(3, el.getSexeEleve());
			pr.setString(4, el.getDateNaissanceEleve());
			pr.setString(5, el.getNationaliteEleve());
			pr.setString(6, el.getEmailEleve());
			pr.setBinaryStream(7, el.getFichier1());
			pr.setBinaryStream(8, el.getFichier2());
            pr.setBoolean(9, el.isValid());
            pr.setString(10, el.getNumIdentite());
           
			pr.executeUpdate();	
			pr.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


	@Override
	public List<EleveSInscrire> elevesParInstitut(String numId) {
		eleve = new ArrayList<EleveSInscrire>();
		EleveSInscrire elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleveSInscrire, dateInscription, matriculeInstitut, nomInstitut, nomSectionCommunale, nomDepartement from InstitutionSeTrouver natural join EleveSInscrire where numIdentite = ?");
			ps.setString(1, numId);
		    ResultSet rs = ps.executeQuery();
		   
while(rs.next()) {
	elev = new EleveSInscrire();
	elev.setIdEleveSInscrire(Long.parseLong(rs.getString("idEleveSInscrire")));
	elev.setDateInscription(rs.getString("dateInscription"));
	elev.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	elev.setNomInstitut(rs.getString("nomInstitut"));
	elev.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	elev.setNomDepartement(rs.getString("nomDepartement"));
    eleve.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(elev == null) throw new RuntimeException("Aucune inscription trouvée pour le NIN "+numId+". Vérifiez et réessayez!");
	return eleve;
	}



	@Override
	public List<EleveSInscrire> dernierInscrit() {
		eleve = new ArrayList<EleveSInscrire>();
		EleveSInscrire elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from EleveSInscrire order by idEleveSInscrire desc limit 1");
		    ResultSet rs = ps.executeQuery();
		   
while(rs.next()) {
	elev = new EleveSInscrire();
	elev.setIdEleveSInscrire(Long.parseLong(rs.getString("idEleveSInscrire")));
	elev.setDateInscription(rs.getString("dateInscription"));
	elev.setNomClasse(rs.getString("nomClasse"));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setAdresseEleve(rs.getString("adresseEleve"));
	elev.setIdInstitutionSeTrouver(Long.parseLong(rs.getString("idInstitutionSeTrouver")));
    eleve.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return eleve;
	}

	

	@Override
	public void add(EleveSInscrire ele) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement pr =null;
		try {		
			pr = conn.prepareStatement("Insert into EleveSInscrire values(?, ?, ?, ?, ?, ?)");
			pr.setString(1, null);
			pr.setString(2, ele.getDateInscription());
			pr.setString(3, ele.getNomClasse());
			pr.setString(4, ele.getNumIdentite());
			pr.setString(5, ele.getAdresseEleve());
			pr.setLong(6, ele.getIdInstitutionSeTrouver());
	
			pr.executeUpdate();
			pr.close();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(pr == null) {
			throw new RuntimeException("Veuillez saisir les informations obligatoires !");
		}else {
			throw new RuntimeException("Informations sauvegardées avec succès !");
		}
	}



	@Override
	public void add(EleveEtreEprouve eleveprouv) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement pr =null;
		try {		
			pr = conn.prepareStatement("Insert into EleveEtreEprouve values(?, ?, ?, ?, ?, ?, ?)");
			pr.setString(1, null);
			pr.setLong(2, eleveprouv.getIdEleveSInscrire());
			pr.setString(3, eleveprouv.getNumIdentite());
			pr.setString(4, eleveprouv.getAnneeAcademique());
			pr.setString(5, eleveprouv.getNomClasse());
			pr.setString(6, eleveprouv.getCodeMatiere());
			pr.setDouble(7, eleveprouv.getNote());
			pr.executeUpdate();
			pr.close();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(pr == null) {
			throw new RuntimeException("Veuillez saisir les informations obligatoires !");
		}else {
			throw new RuntimeException("Informations sauvegardées avec succès !");
		}
	}



	@Override
	public List<EleveEtreEprouve> eleveEprouve(Long id) {
		elevep = new ArrayList<EleveEtreEprouve>();
		EleveEtreEprouve elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleveSInscrire, numIdentite, anneeAcademique, nomClasse, codeMatiere, libelle, note, base FROM EleveEtreEprouve natural join Matiere where idEleveSInscrire =?");
		    ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
while(rs.next()) {
	elev = new EleveEtreEprouve();
	elev.setIdEleveSInscrire(Long.parseLong(rs.getString("idEleveSInscrire")));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setAnneeAcademique(rs.getString("anneeAcademique"));
	elev.setNomClasse(rs.getString("nomClasse"));
	elev.setCodeMatiere(rs.getString("codeMatiere"));
	elev.setLibelle(rs.getString("libelle"));
	elev.setNote(rs.getDouble("note"));
	elev.setBase(rs.getInt("base"));
	elevep.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	if(elev == null) throw new RuntimeException("Aucune note trouvée pour l'ID "+id+" !");
	return elevep;
	}
	
	
	
	@Override
	public List<EleveEtreEprouve> eleveEprouve(String numId) {
		elevep = new ArrayList<EleveEtreEprouve>();
		EleveEtreEprouve elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleveSInscrire, numIdentite, anneeAcademique, nomClasse, codeMatiere, libelle, note, base FROM EleveEtreEprouve natural join Matiere where numIdentite =?");
		    ps.setString(1, numId);
			ResultSet rs = ps.executeQuery();
while(rs.next()) {
	elev = new EleveEtreEprouve();
	elev.setIdEleveSInscrire(Long.parseLong(rs.getString("idEleveSInscrire")));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setAnneeAcademique(rs.getString("anneeAcademique"));
	elev.setNomClasse(rs.getString("nomClasse"));
	elev.setCodeMatiere(rs.getString("codeMatiere"));
	elev.setLibelle(rs.getString("libelle"));
	elev.setNote(rs.getDouble("note"));
	elev.setBase(rs.getInt("base"));
	elevep.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	if(elev == null) throw new RuntimeException("Aucune note trouvée pour le NIN "+numId+" !");
	return elevep;
	}
  
	

	@Override
	public List<EleveEtreEprouve> derniereNote() {
		elevep = new ArrayList<EleveEtreEprouve>();
		EleveEtreEprouve elev = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select idEleveSInscrire, numIdentite, anneeAcademique, nomClasse, codeMatiere, libelle, note, base FROM EleveEtreEprouve natural join Matiere order by idEleveEtreEprouve desc limit 1");
			ResultSet rs = ps.executeQuery();
if(rs.next()) {
	elev = new EleveEtreEprouve();
	elev.setIdEleveSInscrire(Long.parseLong(rs.getString("idEleveSInscrire")));
	elev.setNumIdentite(rs.getString("numIdentite"));
	elev.setAnneeAcademique(rs.getString("anneeAcademique"));
	elev.setNomClasse(rs.getString("nomClasse"));
	elev.setCodeMatiere(rs.getString("codeMatiere"));
	elev.setLibelle(rs.getString("libelle"));
	elev.setNote(rs.getDouble("note"));
	elev.setBase(rs.getInt("base"));
	elevep.add(elev);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return elevep;
	}

	

//Institution
	
	public static Institution login(Institution institution) {
		//preparing some objects for connection 
	      Statement stmt = null;    	
	      String nomUtilisateur = institution.getNomUtilisateur();    
	      String motPasse = institution.getMotPasse();
	      
		    
	      String searchQuery = "select * from Institution where nomUtilisateur='"+nomUtilisateur+"' AND motPasse='"+motPasse+"'";		    
	   
	      // "System.out.println" prints in the console; Normally used to trace the process
	   System.out.println("Your user name is " +nomUtilisateur);          
	   System.out.println("Your password is " +motPasse);
	   System.out.println("Query: "+searchQuery);
		    
	   try 
	   {   //connect to db_AidEdu 
	      currentCon = ConnectionManager.getConnection();
	      stmt = currentCon.createStatement();
	      rs = stmt.executeQuery(searchQuery);	        
	      boolean more = rs.next();
		       
	      // if user does not exist set the isStatut variable to false
	      if (!more) 
	      {

	    	 System.out.println("Sorry, you are not a registered user! Please sign up first");
	         institution.setValid(false);
	      } 
		        
	      //if user exists set the isStatut variable to true
	      else if (more) 
	      {
	    	  String email = rs.getString("emailInstitut");
	    	  String nomInstit = rs.getString("nomInstitut");
	    	  String type = rs.getString("typeInstitut");
	    	  
	         System.out.println("Adresse de courrier :" + email);
	         System.out.println("Nom d'institution :" + nomInstit);
	         System.out.println("Type :" + type);
	         
	         institution.setEmailInstitut(email);
	         institution.setNomInstitut(nomInstit);
	         institution.setTypeInstitut(type);
	         institution.setValid(true);
	      } 
	    } 
	   catch (Exception ex) 
	   {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 
		    
	   //some exception handling
	   finally 
	   {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (stmt != null) {
	         try {
	            stmt.close();
	         } catch (Exception e) {}
	            stmt = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	         }

	         currentCon = null;
	      }
	   }

	return institution;
	}

	
	@Override
	public void add(Institution inst){
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement pr =null;
		try {
			pr = conn.prepareStatement("Insert into Institution values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			pr.setString(1, inst.getMatriculeInstitut());
			pr.setString(2, inst.getNomInstitut());
			pr.setString(3, inst.getAcronyme());
			pr.setString(4, inst.getNomUtilisateur());
            pr.setString(5, inst.getMotPasse());
			pr.setString(6, inst.getEmailInstitut());
			pr.setString(7, inst.getDateFondation());
			pr.setString(8, inst.getTelephone());
			pr.setString(9, inst.getCycleInstitut());
			pr.setString(10, inst.getTypeInstitut());
			pr.setBinaryStream(11, inst.getFichier());
            pr.setBoolean(12, inst.isValid());
			
			pr.executeUpdate();
			pr.close();
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(pr == null) {
			throw new RuntimeException("Veuillez saisir les informations obligatoires !");
		}else {
			throw new RuntimeException("Informations sauvegardées avec succès !");
		}
		
	}
	

	
	@Override
	public List<Institution> listInstitutions() {
		institutions = new ArrayList<Institution>();
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, emailInstitut, dateFondation, telephone, cycleInstitut, typeInstitut, nomSectionCommunale, valid from Institution natural join InstitutionSeTrouver");
		    ResultSet rs = ps.executeQuery();
		    
while(rs.next()) {
	Institution instit = new Institution(); 
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setAcronyme(rs.getString("acronyme"));
	instit.setNomUtilisateur(rs.getString("nomUtilisateur"));
	instit.setEmailInstitut(rs.getString("emailInstitut"));
	instit.setDateFondation(rs.getString("dateFondation"));
	instit.setTelephone(rs.getString("telephone"));
	instit.setCycleInstitut(rs.getString("cycleInstitut"));
	instit.setTypeInstitut(rs.getString("typeInstitut"));
	instit.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	instit.setValid(rs.getBoolean("valid"));
	
	institutions.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return institutions;
	}

	
	@Override
	public List<Institution> derniereInstitution() {
		institutions = new ArrayList<Institution>();
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM Institution order by matriculeInstitut desc limit 1");
		    ResultSet rs = ps.executeQuery();
		    
while(rs.next()) {
	Institution instit = new Institution(); 
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setAcronyme(rs.getString("acronyme"));
	instit.setNomUtilisateur(rs.getString("nomUtilisateur"));
	instit.setMotPasse(rs.getString("motPasse"));
	instit.setEmailInstitut(rs.getString("emailInstitut"));
	instit.setDateFondation(rs.getString("dateFondation"));
	instit.setTelephone(rs.getString("telephone"));
	instit.setCycleInstitut(rs.getString("cycleInstitut"));
	instit.setTypeInstitut(rs.getString("typeInstitut"));
	instit.setFichier(rs.getBinaryStream("fichier"));
	instit.setValid(rs.getBoolean("valid"));
	
	institutions.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return institutions;
	}

	
	@Override
	public void add(InstitutionSeTrouver instrouv) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement pr =null;
		try {
			pr = conn.prepareStatement("Insert into InstitutionSeTrouver values(?, ?, ?, ?, ?, ?)");
			pr.setString(1, null);
			pr.setString(2, instrouv.getMatriculeInstitut());
			pr.setString(3, instrouv.getNomInstitut());
			pr.setString(4, instrouv.getAdresse());
			pr.setString(5, instrouv.getNomSectionCommunale());
			pr.setString(6, instrouv.getNomDepartement());
			
			pr.executeUpdate();
			pr.close();
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(pr == null) {
			throw new RuntimeException("Veuillez saisir les informations obligatoires !");
		}else {
			throw new RuntimeException("Informations sauvegardées avec succès !");
		}
	}

	
	@Override
	public List<InstitutionSeTrouver> derniereLocalisation() {
		institutrouv = new ArrayList<InstitutionSeTrouver>();
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM InstitutionSeTrouver order by idInstitutionSeTrouver desc limit 1");
		    ResultSet rs = ps.executeQuery();
		    
while(rs.next()) {
	InstitutionSeTrouver instit = new InstitutionSeTrouver(); 
	instit.setIdInstitutionSeTrouver(Long.parseLong(rs.getString("idInstitutionSeTrouver")));
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setAdresse(rs.getString("adresse"));
	instit.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	instit.setNomDepartement(rs.getString("nomDepartement"));
	
	institutrouv.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return institutrouv;
	}


	@Override
	public List<Institution> institutionsParMC(String moc) {
		institutions = new ArrayList<Institution>();
		Institution instit = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, motPasse, emailInstitut, dateFondation, telephone, cycleInstitut, typeInstitut, nomSectionCommunale, fichier, valid from Institution natural join InstitutionSeTrouver where nomInstitut like ?");
		    ps.setString(1, "%"+moc+"%");
			ResultSet rs = ps.executeQuery();
while(rs.next()) {
	instit = new Institution();
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setAcronyme(rs.getString("acronyme"));
	instit.setNomUtilisateur(rs.getString("nomUtilisateur"));
	instit.setMotPasse(rs.getString("motPasse"));
	instit.setEmailInstitut(rs.getString("emailInstitut"));
	instit.setDateFondation(rs.getString("dateFondation"));
	instit.setTelephone(rs.getString("telephone"));
	instit.setCycleInstitut(rs.getString("cycleInstitut"));
	instit.setTypeInstitut(rs.getString("typeInstitut"));
	instit.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	instit.setFichier(rs.getBinaryStream("fichier"));
	instit.setValid(rs.getBoolean("valid"));
	
	institutions.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		if(instit == null) throw new RuntimeException("Aucun nom d'institution contenant '"+moc+"' trouvé !");
		return institutions;
	}

	@Override
	public List<Institution> getInstitution(String matricu) {
		institutions = new ArrayList<Institution>();
		Institution instit = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select matriculeInstitut, nomInstitut, acronyme, nomUtilisateur, emailInstitut, dateFondation, telephone, cycleInstitut, typeInstitut, nomSectionCommunale, valid from Institution natural join InstitutionSeTrouver where matriculeInstitut = ?");
			ps.setString(1, matricu);
		    ResultSet rs = ps.executeQuery();
		   
if(rs.next()) {
	instit = new Institution();
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setAcronyme(rs.getString("acronyme"));
	instit.setNomUtilisateur(rs.getString("nomUtilisateur"));
	instit.setEmailInstitut(rs.getString("emailInstitut"));
	instit.setDateFondation(rs.getString("dateFondation"));
	instit.setTelephone(rs.getString("telephone"));
	instit.setCycleInstitut(rs.getString("cycleInstitut"));
	instit.setTypeInstitut(rs.getString("typeInstitut"));
	instit.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	instit.setValid(rs.getBoolean("valid"));
	
	institutions.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(instit == null) throw new RuntimeException("Numéro de Matricule: '"+matricu+"' introuvable. Vérifiez et réessayez!");
	return institutions;
	}


	@Override
	public List<Institution> institutionParSection(String nomSect) {
		institutions = new ArrayList<Institution>();
		InstitutionSeTrouver instit = null;
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select matriculeInstitut, nomInstitut, typeInstitut, adresse, nomSectionCommunale, nomDepartement, valid from InstitutionSeTrouver natural join Institution where nomSectionCommunale = ?");
			ps.setString(1, nomSect);
		    ResultSet rs = ps.executeQuery();
		   
while(rs.next()) {
	instit = new InstitutionSeTrouver();
	instit.setMatriculeInstitut(rs.getString("matriculeInstitut"));
	instit.setNomInstitut(rs.getString("nomInstitut"));
	instit.setTypeInstitut(rs.getString("typeInstitut"));
	instit.setAdresse(rs.getString("adresse"));
	instit.setNomSectionCommunale(rs.getString("nomSectionCommunale"));
	instit.setNomDepartement(rs.getString("nomDepartement"));
	instit.setValid(rs.getBoolean("valid"));
	
	institutions.add(instit);
	}
     ps.close();
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return institutions;
	}
	
	
	@Override
	public void updateInstitution(Institution inst) {
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement pr = conn.prepareStatement("update Institution set nomInstitut=?, acronyme=?, nomUtilisateur=?, motPasse=?, emailInstitut=?, dateFondation=?, telephone=?, cycleInstitut=?, typeInstitut=?, fichier=?, valid=? where matriculeInstitut=?");
			pr.setString(1, inst.getNomInstitut());
			pr.setString(2, inst.getAcronyme());
			pr.setString(3, inst.getNomUtilisateur());
            pr.setString(4, inst.getMotPasse());
			pr.setString(5, inst.getEmailInstitut());
			pr.setString(6, inst.getDateFondation());
			pr.setString(7, inst.getTelephone());
			pr.setString(8, inst.getCycleInstitut());
			pr.setString(9, inst.getTypeInstitut());
			pr.setBinaryStream(10, inst.getFichier());
            pr.setBoolean(11, inst.isValid());
			pr.setString(12, inst.getMatriculeInstitut());
                      
			pr.executeUpdate();	
			pr.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	
//Personnel
	public static Personnel login(Personnel personnel) {
		 //preparing some objects for connection 
	      Statement stmt = null;    
		
	      String email = personnel.getEmail();  
	      String motDePas = personnel.getMotDePas();
		    
	      String searchQuery = "select * from Personnel where email ='"+email+"' AND motDePas='"+motDePas+"'";		    
	   
	      // "System.out.println" prints in the console; Normally used to trace the process
	   System.out.println("Your mail is " +email);          
	   System.out.println("Your password is " +motDePas);
	   System.out.println("Query: "+searchQuery);
		    
	   try 
	   {   //connect to db_AidEdu 
	      currentCon = ConnectionManager.getConnection();
	      stmt = currentCon.createStatement();
	      rs = stmt.executeQuery(searchQuery);	        
	      boolean more = rs.next();
		       
	      // if user does not exist set the isStatut variable to false
	      if (!more) 
	      {
	    	 System.out.println("Sorry, you are not a registered user! Please sign up first");
	         personnel.setValid(false);
	      } 
		        
	      //if user exists set the isStatut variable to true
	      else if (more) 
	      {
	         
	    	 String nom = rs.getString("nom");
	    	 String prenom = rs.getString("prenom");
	    	 String nIF = rs.getString("nIF");
	    	
	    	 System.out.println("Ton Nom :" +nom);
	         System.out.println("Ton prenom :" +prenom);
	         personnel.setNom(nom);
	         personnel.setPrenom(prenom);
	         personnel.setnIF(nIF);
	      
	         
	         personnel.setValid(true);
	      } 
	    } 
	   catch (Exception ex) 
	   {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 
		    
	   //some exception handling
	   finally 
	   {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (stmt != null) {
	         try {
	            stmt.close();
	         } catch (Exception e) {}
	            stmt = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	         }

	         currentCon = null;
	      }
	   }

	return personnel;
	}

	
}