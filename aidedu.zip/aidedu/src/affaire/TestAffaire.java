package affaire;

import java.util.List;

public class TestAffaire {

	public static void main(String[] args) {
	
		
		IOperation affaire = new OperationImpl();
		
		//affaire.add(new Personne("DURANT","Ely" , "M", "1989-11-02", "Americaine"));
		//affaire.add(new Eleve(1L,"du012214", "at230290", "",null, true));
		
		System.out.println("----------------------------------------");
		
		List<Eleve> Eleves = affaire.listEleves();
		for (Eleve e:Eleves) {
			System.out.print(e.getPrenomEleve() );
			System.out.print(e.getNomEleve() );
			System.out.println(e.isValid() );
		}/*
		System.out.println("----------------------------------------");
		List<Eleve> Eleves1 = affaire.elevesParMC("s");
		for (Eleve e:Eleves1) {
			System.out.println(e.getPrenom() );
		}	
		
		System.out.println("----------------------------------------");
		try {
			List<Eleve> Eleves2 = affaire.getEleve("au112914");
			for (Eleve e:Eleves2) {
			System.out.println(e.getPrenom() );
			System.out.println(e.getEmailEleve() );
			System.out.println(e.getNom() );	
			}
		} catch(Exception e) {
			System.out.println(e.getMessage() );
		}*/
		
		
		System.out.println("----------------------------------------");
		try {
			Eleve El = affaire.trouverEleve("nad000001");
			El.setEmailEleve("marinade90@gmail.com");
			El.setValid(true);
			affaire.updateEleve(El);
			
			System.out.println(El.getPrenomEleve() );
			System.out.println(El.getEmailEleve() );
			System.out.println(El.isValid() );
			System.out.println(El.getNomEleve() );	
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	
	}
}
