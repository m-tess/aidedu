package affaire;

public class SectionCommunale extends Commune {
	private String codePostalSectionCommunale;
	private String nomSectionCommunale;
	
	public String getCodePostalSectionCommunale() {
		return codePostalSectionCommunale;
	}
	public void setCodePostalSectionCommunale(String codePostalSectionCommunale) {
		this.codePostalSectionCommunale = codePostalSectionCommunale;
	}
	public String getNomSectionCommunale() {
		return nomSectionCommunale;
	}
	public void setNomSectionCommunale(String nomSectionCommunale) {
		this.nomSectionCommunale = nomSectionCommunale;
	}
	public SectionCommunale() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SectionCommunale(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public SectionCommunale(String codePostalSectionCommunale, String nomSectionCommunale) {
		super();
		this.codePostalSectionCommunale = codePostalSectionCommunale;
		this.nomSectionCommunale = nomSectionCommunale;
	}
	
	
	
	

}
