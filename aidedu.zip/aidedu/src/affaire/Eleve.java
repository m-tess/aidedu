package affaire;

import java.io.InputStream;

public class Eleve {
	private Long idEleve;
	private String numIdentite;
    private String motPass;
    private String nomEleve;
    private String prenomEleve;
    private String sexeEleve;
    private String dateNaissanceEleve;
    private String nationaliteEleve;
	private String emailEleve;
	private InputStream fichier1;
	private InputStream fichier2;
	public boolean valid;
	
	public Long getIdEleve() {
		return idEleve;
	}
	public void setIdEleve(Long idEleve) {
		this.idEleve = idEleve;
	}
	public String getNumIdentite() {
		return numIdentite;
	}
	public void setNumIdentite(String numIdentite) {
		this.numIdentite = numIdentite;
	}
	public String getMotPass() {
		return motPass;
	}
	public void setMotPass(String motPass) {
		this.motPass = motPass;
	}
	public String getNomEleve() {
		return nomEleve;
	}
	public void setNomEleve(String nomEleve) {
		this.nomEleve = nomEleve;
	}
	public String getPrenomEleve() {
		return prenomEleve;
	}
	public void setPrenomEleve(String prenomEleve) {
		this.prenomEleve = prenomEleve;
	}
	public String getSexeEleve() {
		return sexeEleve;
	}
	public void setSexeEleve(String sexeEleve) {
		this.sexeEleve = sexeEleve;
	}
	public String getDateNaissanceEleve() {
		return dateNaissanceEleve;
	}
	public void setDateNaissanceEleve(String dateNaissanceEleve) {
		this.dateNaissanceEleve = dateNaissanceEleve;
	}
	public String getNationaliteEleve() {
		return nationaliteEleve;
	}
	public void setNationaliteEleve(String nationaliteEleve) {
		this.nationaliteEleve = nationaliteEleve;
	}
	public String getEmailEleve() {
		return emailEleve;
	}
	public void setEmailEleve(String emailEleve) {
		this.emailEleve = emailEleve;
	}
	public InputStream getFichier1() {
		return fichier1;
	}
	public void setFichier1(InputStream fichier1) {
		this.fichier1 = fichier1;
	}
	public InputStream getFichier2() {
		return fichier2;
	}
	public void setFichier2(InputStream fichier2) {
		this.fichier2 = fichier2;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	public Eleve() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Eleve(String numIdentite, String motPass, String nomEleve, String prenomEleve, String sexeEleve,
			String dateNaissanceEleve, String nationaliteEleve, String emailEleve, InputStream fichier1,
			InputStream fichier2, boolean valid) {
		super();
		this.numIdentite = numIdentite;
		this.motPass = motPass;
		this.nomEleve = nomEleve;
		this.prenomEleve = prenomEleve;
		this.sexeEleve = sexeEleve;
		this.dateNaissanceEleve = dateNaissanceEleve;
		this.nationaliteEleve = nationaliteEleve;
		this.emailEleve = emailEleve;
		this.fichier1 = fichier1;
		this.fichier2 = fichier2;
		this.valid = valid;
	}
	
	
	
}
