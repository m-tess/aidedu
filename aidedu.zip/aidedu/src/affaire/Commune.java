package affaire;

public class Commune extends Departement {
	private String codePostalCommune;
	private String nomCommune;
	
	public String getCodePostalCommune() {
		return codePostalCommune;
	}
	public void setCodePostalCommune(String codePostalCommune) {
		this.codePostalCommune = codePostalCommune;
	}
	public String getNomCommune() {
		return nomCommune;
	}
	public void setNomCommune(String nomCommune) {
		this.nomCommune = nomCommune;
	}
	public Commune() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Commune(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public Commune(String codePostalCommune, String nomCommune) {
		super();
		this.codePostalCommune = codePostalCommune;
		this.nomCommune = nomCommune;
	}
	
}
