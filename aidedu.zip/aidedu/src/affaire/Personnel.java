package affaire;

import java.sql.Blob;

public class Personnel {
	private Long idPersonnel;
	private String nIF;
	private String email;
    private String motDePas;
    private String nom;
    private String prenom;
    private String sexe;
    private String dateNaissance;
    private String nationalite;
	private String poste;
	private Blob fichier;
	public boolean valid;
	
	public Long getIdPersonnel() {
		return idPersonnel;
	}
	public void setIdPersonnel(Long idPersonnel) {
		this.idPersonnel = idPersonnel;
	}
	public String getnIF() {
		return nIF;
	}
	public void setnIF(String nIF) {
		this.nIF = nIF;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMotDePas() {
		return motDePas;
	}
	public void setMotDePas(String motDePas) {
		this.motDePas = motDePas;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	public String getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	public String getNationalite() {
		return nationalite;
	}
	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}
	public String getPoste() {
		return poste;
	}
	public void setPoste(String poste) {
		this.poste = poste;
	}
	public Blob getFichier() {
		return fichier;
	}
	public void setFichier(Blob fichier) {
		this.fichier = fichier;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	public Personnel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Personnel(String nIF, String email, String motDePas, String nom, String prenom, String sexe,
			String dateNaissance, String nationalite, String poste, Blob fichier, boolean valid) {
		super();
		this.nIF = nIF;
		this.email = email;
		this.motDePas = motDePas;
		this.nom = nom;
		this.prenom = prenom;
		this.sexe = sexe;
		this.dateNaissance = dateNaissance;
		this.nationalite = nationalite;
		this.poste = poste;
		this.fichier = fichier;
		this.valid = valid;
	}
	
	
}
