package affaire;

public class EleveSInscrire extends InstitutionSeTrouver {
	private Long idEleveSInscrire;
	private String dateInscription;
	private String nomClasse;
	private String numIdentite;
	private String adresseEleve;
	private Long idInstitutionSeTrouver;
	
	public Long getIdEleveSInscrire() {
		return idEleveSInscrire;
	}
	public void setIdEleveSInscrire(Long idEleveSInscrire) {
		this.idEleveSInscrire = idEleveSInscrire;
	}
	public String getDateInscription() {
		return dateInscription;
	}
	public void setDateInscription(String dateInscription) {
		this.dateInscription = dateInscription;
	}
	public String getNomClasse() {
		return nomClasse;
	}
	public void setNomClasse(String nomClasse) {
		this.nomClasse = nomClasse;
	}
	public String getNumIdentite() {
		return numIdentite;
	}
	public void setNumIdentite(String numIdentite) {
		this.numIdentite = numIdentite;
	}
	public String getAdresseEleve() {
		return adresseEleve;
	}
	public void setAdresseEleve(String adresseEleve) {
		this.adresseEleve = adresseEleve;
	}
	public Long getIdInstitutionSeTrouver() {
		return idInstitutionSeTrouver;
	}
	public void setIdInstitutionSeTrouver(Long idInstitutionSeTrouver) {
		this.idInstitutionSeTrouver = idInstitutionSeTrouver;
	}
	public EleveSInscrire() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EleveSInscrire(String nomInstitut, String nomSectionCommunale) {
		super(nomInstitut, nomSectionCommunale);
		// TODO Auto-generated constructor stub
	}
	public EleveSInscrire(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public EleveSInscrire(String dateInscription, String nomClasse, String numIdentite, String adresseEleve,
			Long idInstitutionSeTrouver) {
		super();
		this.dateInscription = dateInscription;
		this.nomClasse = nomClasse;
		this.numIdentite = numIdentite;
		this.adresseEleve = adresseEleve;
		this.idInstitutionSeTrouver = idInstitutionSeTrouver;
	}
	
	
}
