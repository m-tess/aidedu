package affaire;

public class CommuneSeTrouver extends Departement {
	private int idCommuneSeTrouver;
	private String nomCommune;
	private String nomDepartement;
	
	public int getIdCommuneSeTrouver() {
		return idCommuneSeTrouver;
	}
	public void setIdCommuneSeTrouver(int idCommuneSeTrouver) {
		this.idCommuneSeTrouver = idCommuneSeTrouver;
	}
	public String getNomCommune() {
		return nomCommune;
	}
	public void setNomCommune(String nomCommune) {
		this.nomCommune = nomCommune;
	}
	public String getNomDepartement() {
		return nomDepartement;
	}
	public void setNomDepartement(String nomDepartement) {
		this.nomDepartement = nomDepartement;
	}
	public CommuneSeTrouver() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CommuneSeTrouver(String nomDepartement) {
		super(nomDepartement);
		// TODO Auto-generated constructor stub
	}
	public CommuneSeTrouver(String nomCommune, String nomDepartement) {
		super();
		this.nomCommune = nomCommune;
		this.nomDepartement = nomDepartement;
	}
	
}
