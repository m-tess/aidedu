package web;

import java.util.ArrayList;
import java.util.List;

import affaire.*;

public class Operation {
	private String motCle;
	private String motClef;
	private String nomSect;
	private String numId;
	private String numIdentite;
	private String matricu;
	private Long id;
	private String erreurs;
	private String mode = "ajout";
	
	private Eleve eleve = new Eleve();
	private EleveSInscrire eleveins = new EleveSInscrire();
	private EleveEtreEprouve eleveprouv = new EleveEtreEprouve();
	private Institution institution = new Institution();
	private InstitutionSeTrouver instrouver = new InstitutionSeTrouver();
	private List<EleveEtreEprouve> elevep = new ArrayList<EleveEtreEprouve>();
	private List<EleveSInscrire> eleveinsc = new ArrayList<EleveSInscrire>();
	private List<Eleve> eleves = new ArrayList<Eleve>();
	private List<Institution> institutions = new ArrayList<Institution>();
	private List<InstitutionSeTrouver> institutrouv = new ArrayList<InstitutionSeTrouver>();
	
	

	public InstitutionSeTrouver getInstrouver() {
		return instrouver;
	}
	public void setInstrouver(InstitutionSeTrouver instrouver) {
		this.instrouver = instrouver;
	}
	public EleveEtreEprouve getEleveprouv() {
		return eleveprouv;
	}
	public void setEleveprouv(EleveEtreEprouve eleveprouv) {
		this.eleveprouv = eleveprouv;
	}
	public List<EleveEtreEprouve> getElevep() {
		return elevep;
	}
	public void setElevep(List<EleveEtreEprouve> elevep) {
		this.elevep = elevep;
	}
	public List<EleveSInscrire> getEleveinsc() {
		return eleveinsc;
	}
	public void setEleveinsc(List<EleveSInscrire> eleveinsc) {
		this.eleveinsc = eleveinsc;
	}
	public EleveSInscrire getEleveins() {
		return eleveins;
	}
	public void setEleveins(EleveSInscrire eleveins) {
		this.eleveins = eleveins;
	}
	public String getNomSect() {
		return nomSect;
	}
	public void setNomSect(String nomSect) {
		this.nomSect = nomSect;
	}
	public String getErreurs() {
		return erreurs;
	}
	public void setErreurs(String erreurs) {
		this.erreurs = erreurs;
	}
	public String getNumId() {
		return numId;
	}
	public void setNumId(String numId) {
		this.numId = numId;
	}
	public Eleve getEleve() {
		return eleve;
	}
	public void setEleve(Eleve eleve) {
		this.eleve = eleve;
	}
	public List<Eleve> getEleves(){
		return eleves;
	}
	public void setEleves(List<Eleve> eleves) {
		this.eleves = eleves;
	}
	
	
	public String getMotCle() {
		return motCle;
	}
	public void setMotCle(String motCle) {
		this.motCle = motCle;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public List<Institution> getInstitutions(){
		return institutions;
	}
	public void setInstitutions(List<Institution> institutions) {
		this.institutions = institutions;
	}
	public String getMotClef() {
		return motClef;
	}
	public void setMotClef(String motClef) {
		this.motClef = motClef;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public String getMatricu() {
		return matricu;
	}
	public void setMatricu(String matricu) {
		this.matricu = matricu;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<InstitutionSeTrouver> getInstitutrouv() {
		return institutrouv;
	}
	public void setInstitutrouv(List<InstitutionSeTrouver> institutrouv) {
		this.institutrouv = institutrouv;
	}
	public String getNumIdentite() {
		return numIdentite;
	}
	public void setNumIdentite(String numIdentite) {
		this.numIdentite = numIdentite;
	}
}
