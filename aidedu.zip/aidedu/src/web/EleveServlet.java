package web;

import affaire.*;


//import java.util.List;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class AccesEleveServlet
 */
/**
 * @author atessa
 *
 */
@WebServlet("/login1")
public class EleveServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	IOperation affaire;
	
	
	@Override
    public void init() throws ServletException {
 	   affaire = new OperationImpl();
    }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	           throws ServletException, java.io.IOException {

     try
       {	    
        Eleve eleve = new Eleve();
        eleve.setNumIdentite(request.getParameter("numIdentite"));
        eleve.setMotPass(request.getParameter("motPass"));

        eleve = OperationImpl.login(eleve);
	    
        if (eleve.isValid())
          {
        	eleve.setValid(true);
        	String nom = eleve.getNomEleve();
	    	String prenom = eleve.getPrenomEleve();
	    	String numId = eleve.getNumIdentite();
	    	
            response.sendRedirect("Eleve.jsp"); //logged-in page 
            HttpSession session = request.getSession(true);
        
            session.setAttribute("welcom", nom);
         	session.setAttribute("welcome", prenom);
         	session.setAttribute("Numero", numId);
         
          }
        else
          {	  
        
        	response.sendRedirect("EspaceEleve.jsp"); //error page 
        	HttpSession session = request.getSession(true);
        	session.setAttribute("error", "<h4>Identifiant ou mot de passe incorrect !!!</h4>");
        	eleve.setValid(false);
          }
        } catch (Throwable theException) 	    
               { 
        	     System.out.println(theException); 
               }
       }
	
	/*
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	           throws ServletException, java.io.IOException {
		String action = request.getParameter("action");
		Operation model = new Operation();

		if(action== null) {	
			if(action.equals("Connecter")) {
				try {
					model.setNumId("numId");
					List<EleveEtreEprouve> elevep = affaire.eleveEprouve(model.getNumId());
					model.setElevep(elevep);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("DataEl.jsp").forward(request, response);
			}	
	}
			
	
	
	}*/
}
	
	

