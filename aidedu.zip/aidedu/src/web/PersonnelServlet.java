package web;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import affaire.*;

/**
 * Servlet implementation class PersonnelServlet
 */
@WebServlet("/login3")
@MultipartConfig(maxFileSize = 16177216)
public class PersonnelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IOperation affaire;


	@Override
	public void init() throws ServletException {
		affaire = new OperationImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{	    
			Personnel personnel = new Personnel();
			personnel.setEmail(request.getParameter("email"));
			personnel.setMotDePas(request.getParameter("motDePas"));

			personnel = OperationImpl.login(personnel);


			if (personnel.isValid() )
			{
				personnel.setValid(true);
				String nom = personnel.getNom();
				String prenom = personnel.getPrenom();

				response.sendRedirect("Personnel.jsp"); //logged-in page
				HttpSession session = request.getSession(true);
				session.setAttribute("welcom", prenom);
				session.setAttribute("welcome", nom);
			}
			else
			{	    
				response.sendRedirect("EspacePersonnel.jsp"); //error page 
				HttpSession session = request.getSession(true);
				session.setAttribute("mistake", "<h4>Adresse &eacute;lectronique ou mot de passe incorrect</h4>");
				personnel.setValid(false);
			}
		} catch (Throwable theException) 	    
		{ 
			System.out.println(theException); 
		}
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, java.io.IOException {

		String action = request.getParameter("action");
		Operation model = new Operation();

		if(action!= null) {	
			if(action.equals("Entrer")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<Eleve> eleves = affaire.getEleve(model.getNumId());
					model.setEleves(eleves);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("RecherchEl.jsp").forward(request, response);

			}else if(action.equals("Afficher")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveEtreEprouve> elevep = affaire.eleveEprouve(model.getNumId());
					model.setElevep(elevep);

				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("ParcoursAcad.jsp").forward(request, response);

			}else if(action.equals("editer")) {
				String numIdi = request.getParameter("numIdentite");
				List<Eleve> ele = affaire.getEleve(numIdi);
				model.setEleves(ele);
				model.setEleves(affaire.listEleves());
				request.setAttribute("model", model);
				request.getRequestDispatcher("AjoutEl.jsp").forward(request, response);

			}else if(action.equals("Rechercher")) {
				try {
					model.setMotCle(request.getParameter("motCle"));
					List<Eleve> eleves = affaire.elevesParMC(model.getMotCle());
					model.setEleves(eleves);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("InfoEl.jsp").forward(request, response);	

			}
			else if(action.equals("Verifier")) {
				try {
					model.setMatricu(request.getParameter("matricu"));
					List<Institution> institutions = affaire.getInstitution(model.getMatricu());
					model.setInstitutions(institutions);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("RecherchInstit.jsp").forward(request, response);
			}
			else if(action.equals("Verification")) {
				try {
					model.setMatricu(request.getParameter("matricu"));
					List<Institution> institutions = affaire.getInstitution(model.getMatricu());
					model.setInstitutions(institutions);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("AjoutInstit.jsp").forward(request, response);
			}
			else if(action.equals("Chercher")) {
				try {
					model.setMotClef(request.getParameter("motClef"));
					List<Institution> institutions = affaire.institutionsParMC(model.getMotClef());
					model.setInstitutions(institutions);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("InfoInstit.jsp").forward(request, response);			
			}
			else if(action.equals("Enregistrer")) {
				Part part = request.getPart("fichier");
				String motPasse = "Password2018";
				InputStream is = part.getInputStream();
				try {
					model.getInstitution().setMatriculeInstitut(request.getParameter("matriculeInstitut"));
					model.getInstitution().setNomInstitut(request.getParameter("nomInstitut"));
					model.getInstitution().setAcronyme(request.getParameter("acronyme"));
					model.getInstitution().setNomUtilisateur(request.getParameter("nomUtilisateur"));
					model.getInstitution().setMotPasse(motPasse);
					model.getInstitution().setEmailInstitut(request.getParameter("emailInstitut"));
					model.getInstitution().setDateFondation(request.getParameter("dateFondation"));
					model.getInstitution().setTelephone(request.getParameter("telephone"));
					model.getInstitution().setCycleInstitut(request.getParameter("cycleInstitut"));
					model.getInstitution().setTypeInstitut(request.getParameter("typeInstitut"));
					model.getInstitution().setFichier(is);
					model.getInstitution().setValid(Boolean.parseBoolean(request.getParameter("valid")));
					affaire.add(model.getInstitution());

				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<Institution> institutions = affaire.derniereInstitution();
				model.setInstitutions(institutions);
				request.setAttribute("model", model);
				request.getRequestDispatcher("AjoutInstit.jsp").forward(request, response);
			}
			else if(action.equals("modifier")) {
				String matricu = request.getParameter("matricu");
				List<Institution> instit = affaire.getInstitution(matricu);
				model.setInstitutions(instit);
				model.setInstitutions(affaire.listInstitutions());
				request.setAttribute("model", model);

				request.getRequestDispatcher("AjoutInstit.jsp").forward(request, response);

			}else if(action.equals("Trouver")) {
				try {
					model.setMotClef(request.getParameter("motClef"));
					List<Institution> institutions = affaire.institutionsParMC(model.getMotClef());
					model.setInstitutions(institutions);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("InfoInstit.jsp").forward(request, response);	
			}
			else if(action.equals("OK")) {
				try {
					model.setNomSect(request.getParameter("nomSect"));
					List<Institution> institutions = affaire.institutionParSection(model.getNomSect());
					model.setInstitutions(institutions);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("ListInstitut.jsp").forward(request, response);
			}
			else if(action.equals("Voir")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveSInscrire> eleveinsc = affaire.elevesParInstitut(model.getNumId());
					model.setEleveinsc(eleveinsc);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Inscription.jsp").forward(request, response);

			}
			else if(action.equals("Sauvegarder")) {
				try {
					model.getInstrouver().setMatriculeInstitut(request.getParameter("matriculeInstitut"));
					model.getInstrouver().setNomInstitut(request.getParameter("nomInstitut"));
					model.getInstrouver().setAdresse(request.getParameter("adresse"));
					model.getInstrouver().setNomSectionCommunale(request.getParameter("nomSectionCommunale"));
					model.getInstrouver().setNomDepartement(request.getParameter("nomDepartement"));
					affaire.add(model.getInstrouver());

				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<InstitutionSeTrouver> institutrouv = affaire.derniereLocalisation();
				model.setInstitutrouv(institutrouv);
				request.setAttribute("model", model);
				request.getRequestDispatcher("Localisation.jsp").forward(request, response);

			}

		}
	}
}
