package web;

import affaire.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;


/**
 * Servlet implementation class InstitutionServlet
 */
@WebServlet("/login2")
@MultipartConfig(maxFileSize = 16177216)
public class InstitutionServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;


	IOperation affaire;


	@Override
	public void init() throws ServletException {
		affaire = new OperationImpl();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, java.io.IOException {

		String action = request.getParameter("action");
		Operation model = new Operation();

		if(action!= null) {	
			if(action.equals("Entrer")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<Eleve> eleves = affaire.getEleve(model.getNumId());
					model.setEleves(eleves);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Institution.jsp").forward(request, response);
			}
			else if(action.equals("Afficher")) {
				try {
					model.setId(Long.parseLong(request.getParameter("id")));
					List<EleveEtreEprouve> elevep = affaire.eleveEprouve(model.getId());
					model.setElevep(elevep);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Parcours.jsp").forward(request, response);	
			}
			else if(action.equals("Afficher +")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveEtreEprouve> elevep = affaire.eleveEprouve(model.getNumId());
					model.setElevep(elevep);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Parcours.jsp").forward(request, response);	
			}
			else if(action.equals("Sauvegarder")) {
				
				String motPass = "Password2018";
				Part part1 = request.getPart("fichier1");
				Part part2 = request.getPart("fichier2");
				InputStream is1 = part1.getInputStream();
				InputStream is2 = part2.getInputStream();
				try {
					model.getEleve().setNumIdentite(request.getParameter("numIdentite"));
					model.getEleve().setMotPass(motPass);
					model.getEleve().setNomEleve(request.getParameter("nomEleve"));
					model.getEleve().setPrenomEleve(request.getParameter("prenomEleve"));
					model.getEleve().setSexeEleve(request.getParameter("sexeEleve"));
					model.getEleve().setDateNaissanceEleve(request.getParameter("dateNaissanceEleve"));
					model.getEleve().setNationaliteEleve(request.getParameter("nationaliteEleve"));
					model.getEleve().setEmailEleve(request.getParameter("emailEleve"));
					model.getEleve().setFichier1(is1);
					model.getEleve().setFichier2(is2);
					model.getEleve().setValid(Boolean.parseBoolean(request.getParameter("valid")));
					
					affaire.add(model.getEleve());
				
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<Eleve> eleves = affaire.dernierEleve();
				model.setEleves(eleves);
				request.setAttribute("model", model);
				request.getRequestDispatcher("Ajout.jsp").forward(request, response);

			}else if(action.equals("Editer")) {
				String numId = request.getParameter("numId");
				
				Eleve eleve = affaire.trouverEleve(numId);
				affaire.updateEleve(model.getEleve());
				
				model.setEleve(eleve);
				model.setMode("editer");
				request.setAttribute("model", model);
				request.getRequestDispatcher("Ajout.jsp").forward(request, response);
				
			}else if(action.equals("Rechercher")) {
				try {
					model.setMotCle(request.getParameter("motCle"));
					List<Eleve> eleves = affaire.elevesParMC(model.getMotCle());
					model.setEleves(eleves);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Info.jsp").forward(request, response);	

			}else if(action.equals("Valider")) {
				String anneeAcademique = "2018-19";
				try {
					model.getEleveprouv().setIdEleveSInscrire(Long.parseLong(request.getParameter("idEleveSInscrire")));
					model.getEleveprouv().setNumIdentite(request.getParameter("numIdentite"));
					model.getEleveprouv().setAnneeAcademique(anneeAcademique);
					model.getEleveprouv().setNomClasse(request.getParameter("nomClasse"));
					model.getEleveprouv().setCodeMatiere(request.getParameter("codeMatiere"));
					model.getEleveprouv().setNote(Double.parseDouble(request.getParameter("note")));
					affaire.add(model.getEleveprouv());

				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<EleveEtreEprouve> elevep = affaire.derniereNote();
				model.setElevep(elevep);
				request.setAttribute("model", model);
				request.getRequestDispatcher("Notes.jsp").forward(request, response);	
			}
			else if(action.equals("Enregistrer")) {
				try {
					model.getEleveins().setDateInscription(request.getParameter("dateInscription"));
					model.getEleveins().setNomClasse(request.getParameter("nomClasse"));
					model.getEleveins().setNumIdentite(request.getParameter("numIdentite"));
					model.getEleveins().setAdresseEleve(request.getParameter("adresseEleve"));
					model.getEleveins().setIdInstitutionSeTrouver(Long.parseLong(request.getParameter("idInstitutionSeTrouver")));
					affaire.add(model.getEleveins());
					
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<EleveSInscrire> eleveinsc = affaire.dernierInscrit();
			    model.setEleveinsc(eleveinsc);
				request.setAttribute("model", model);
				request.getRequestDispatcher("InscriptionEleve.jsp").forward(request, response);	
			}
			else if(action.equals("Verifier")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<Eleve> eleves = affaire.getEleve(model.getNumId());
					model.setEleves(eleves);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Institution1.jsp").forward(request, response);

			}
			else if(action.equals("Voir")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveSInscrire> eleveinsc = affaire.elevesParInstitut(model.getNumId());
					model.setEleveinsc(eleveinsc);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Inscript.jsp").forward(request, response);

			}
			else if(action.equals("Parcourir")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveEtreEprouve> elevep = affaire.eleveEprouve(model.getNumId());
					model.setElevep(elevep);

				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Parc.jsp").forward(request, response);	

			}
			else if(action.equals("Accepter")) {
				String nomClasse = null;
				try {
					model.getEleveins().setDateInscription(request.getParameter("dateInscription"));
					model.getEleveins().setNomClasse(nomClasse);
					model.getEleveins().setNumIdentite(request.getParameter("numIdentite"));
					model.getEleveins().setAdresseEleve(request.getParameter("adresseEleve"));
					model.getEleveins().setIdInstitutionSeTrouver(Long.parseLong(request.getParameter("idInstitutionSeTrouver")));
					affaire.add(model.getEleveins());
					
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				List<EleveSInscrire> eleveinsc = affaire.dernierInscrit();
			    model.setEleveinsc(eleveinsc);
				request.setAttribute("model", model);
				request.getRequestDispatcher("InscriptionE.jsp").forward(request, response);	
			}
			else if(action.equals("Visualiser")) {
				try {
					model.setNumId(request.getParameter("numId"));
					List<EleveSInscrire> eleveinsc = affaire.elevesParInstitut(model.getNumId());
					model.setEleveinsc(eleveinsc);
				}catch(Exception e) {
					model.setErreurs(e.getMessage());
				}
				request.setAttribute("model", model);
				request.getRequestDispatcher("Frequentation.jsp").forward(request, response);

			}

		}
	}
	
	
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{	    
			Institution institution = new Institution();
			institution.setNomUtilisateur(request.getParameter("nomUtilisateur"));
			institution.setMotPasse(request.getParameter("motPasse"));
			
			institution = OperationImpl.login(institution);

			if (institution.isValid())
			{
				if(institution.getTypeInstitut().equals("Ecole"))
				{
                   institution.setValid(true);
	               String nomInstitut = institution.getNomInstitut();
	               

	               response.sendRedirect("Institution.jsp"); //logged-in page  
	               HttpSession session = request.getSession(true);
	               session.setAttribute("welcome", nomInstitut);
	              
                 }else{
                      	institution.setValid(true);
                    	String nom = institution.getNomInstitut();

	                    response.sendRedirect("Institution1.jsp"); //logged-in page  
	                    HttpSession session = request.getSession(true);
	                    session.setAttribute("welcome", nom);
                      }
			}
			else
			{	    
				response.sendRedirect("EspaceInstitution.jsp"); //error page 
				HttpSession session = request.getSession(true);
				session.setAttribute("erreur", "<h4>Nom d'utilisateur ou mot de passe incorrect !!!</h4>");
				institution.setValid(false);
			}
		} catch (Throwable theException) 	    
		{ 
			System.out.println(theException); 
		}
	}

}
