/*
MySQL - 5.0.26-community-nt : Database - db_AidEdu
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_AidEdu` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_AidEdu`;

/*Table structure for table `Classe` */

DROP TABLE IF EXISTS `Classe`;

CREATE TABLE `Classe` (
  `idClasse` int(4) NOT NULL auto_increment,
  `nomClasse` varchar(25) NOT NULL,
  PRIMARY KEY  (`idClasse`),
  UNIQUE KEY `nomClasse` (`nomClasse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Classe` */

/*Table structure for table `Commune` */

DROP TABLE IF EXISTS `Commune`;

CREATE TABLE `Commune` (
  `idCommune` int(4) NOT NULL auto_increment,
  `codePostalCommune` char(6) NOT NULL,
  `nomCommune` varchar(30) NOT NULL,
  PRIMARY KEY  (`idCommune`),
  UNIQUE KEY `codePostalCommune` (`codePostalCommune`),
  UNIQUE KEY `nomCommune` (`nomCommune`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Commune` */

/*Table structure for table `CommuneSeTrouver` */

DROP TABLE IF EXISTS `CommuneSeTrouver`;

CREATE TABLE `CommuneSeTrouver` (
  `idCommuneSeTrouver` int(4) NOT NULL auto_increment,
  `nomCommune` varchar(30) NOT NULL,
  `nomDepartement` varchar(20) NOT NULL,
  PRIMARY KEY  (`idCommuneSeTrouver`),
  UNIQUE KEY `idCommuneSeTrouver` (`idCommuneSeTrouver`),
  KEY `nomCommune` (`nomCommune`),
  KEY `nomDepartement` (`nomDepartement`),
  CONSTRAINT `communesetrouver_ibfk_1` FOREIGN KEY (`nomCommune`) REFERENCES `Commune` (`nomCommune`),
  CONSTRAINT `communesetrouver_ibfk_2` FOREIGN KEY (`nomDepartement`) REFERENCES `Departement` (`nomDepartement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `CommuneSeTrouver` */

/*Table structure for table `Departement` */

DROP TABLE IF EXISTS `Departement`;

CREATE TABLE `Departement` (
  `idDepartement` int(4) NOT NULL auto_increment,
  `nomDepartement` varchar(20) NOT NULL,
  PRIMARY KEY  (`idDepartement`),
  UNIQUE KEY `nomDepartement` (`nomDepartement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Departement` */

/*Table structure for table `Eleve` */

DROP TABLE IF EXISTS `Eleve`;

CREATE TABLE `Eleve` (
  `idEleve` bigint(20) NOT NULL auto_increment,
  `numIdentite` char(9) NOT NULL,
  `motPass` varchar(100) NOT NULL,
  `nomEleve` varchar(250) NOT NULL,
  `prenomEleve` varchar(250) NOT NULL,
  `sexeEleve` char(1) NOT NULL,
  `dateNaissanceEleve` char(10) NOT NULL,
  `nationaliteEleve` varchar(30) NOT NULL,
  `emailEleve` varchar(50) default NULL,
  `fichier1` LONGBLOB NOT NULL,
  `fichier2` LONGBLOB default NULL,
  `valid` tinyint(1) default NULL,
  `statutE` varchar(7) NOT NULL,
  PRIMARY KEY  (`idEleve`),
  UNIQUE KEY `numIdentite` (`numIdentite`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Eleve` */

/*Table structure for table `EleveEtreEprouve` */

DROP TABLE IF EXISTS `EleveEtreEprouve`;

CREATE TABLE `EleveEtreEprouve` (
  `idEleveEtreEprouve` bigint(20) NOT NULL auto_increment,
  `idEleveSInscrire` bigint(20) NOT NULL,
  `numIdentite` char(9) NOT NULL,
  `anneeAcademique` char(7) NOT NULL,
  `nomClasse` varchar(25) default NULL,
  `codeMatiere` char(6) NOT NULL,
  `note` double NOT NULL,
  PRIMARY KEY  (`idEleveEtreEprouve`),
  UNIQUE KEY `idEleveEtreEprouve` (`idEleveEtreEprouve`),
  KEY `idEleveSInscrire` (`idEleveSInscrire`),
  KEY `numIdentite` (`numIdentite`),
  KEY `nomClasse` (`nomClasse`),
  KEY `codeMatiere` (`codeMatiere`),
  CONSTRAINT `eleveetreeprouve_ibfk_1` FOREIGN KEY (`idEleveSInscrire`) REFERENCES `EleveSInscrire` (`idEleveSInscrire`),
  CONSTRAINT `eleveetreeprouve_ibfk_2` FOREIGN KEY (`numIdentite`) REFERENCES `EleveSInscrire` (`numIdentite`),
  CONSTRAINT `eleveetreeprouve_ibfk_3` FOREIGN KEY (`nomClasse`) REFERENCES `Classe` (`nomClasse`),
  CONSTRAINT `eleveetreeprouve_ibfk_4` FOREIGN KEY (`codeMatiere`) REFERENCES `Matiere` (`codeMatiere`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `EleveEtreEprouve` */

/*Table structure for table `EleveSInscrire` */

DROP TABLE IF EXISTS `EleveSInscrire`;

CREATE TABLE `EleveSInscrire` (
  `idEleveSInscrire` bigint(20) NOT NULL auto_increment,
  `dateInscription` char(10) NOT NULL,
  `nomClasse` varchar(25) default NULL,
  `numIdentite` char(9) NOT NULL,
  `adresseEleve` varchar(255) NOT NULL,
  `idInstitutionSeTrouver` bigint(20) NOT NULL,
  PRIMARY KEY  (`idEleveSInscrire`),
  UNIQUE KEY `idEleveSInscrire` (`idEleveSInscrire`),
  KEY `nomClasse` (`nomClasse`),
  KEY `numIdentite` (`numIdentite`),
  KEY `idInstitutionSeTrouver` (`idInstitutionSeTrouver`),
  CONSTRAINT `elevesinscrire_ibfk_1` FOREIGN KEY (`nomClasse`) REFERENCES `Classe` (`nomClasse`),
  CONSTRAINT `elevesinscrire_ibfk_2` FOREIGN KEY (`numIdentite`) REFERENCES `Eleve` (`numIdentite`),
  CONSTRAINT `elevesinscrire_ibfk_3` FOREIGN KEY (`idInstitutionSeTrouver`) REFERENCES `InstitutionSeTrouver` (`idInstitutionSeTrouver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `EleveSInscrire` */

/*Table structure for table `Institution` */

DROP TABLE IF EXISTS `Institution`;

CREATE TABLE `Institution` (
  `idInstitut` int(4) NOT NULL auto_increment,
  `matriculeInstitut` char(15) NOT NULL,
  `nomInstitut` varchar(50) NOT NULL,
  `acronyme` varchar(10) default NULL,
  `nomDG` varchar(250) NOT NULL,
  `prenomDG` varchar(250) NOT NULL,
  `emailInstitut` varchar(100) NOT NULL,
  `dateFondation` char(10) NOT NULL,
  `telephone` varchar(40) NOT NULL,
  `typeInstitut` char(11)NOT NULL,
  `fichier` LONGBLOB NOT NULL,
  PRIMARY KEY  (`idInstitut`),
  UNIQUE KEY  (`matriculeInstitut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Institution` */

/*Table structure for table `InstitutionSeTrouver` */

DROP TABLE IF EXISTS `InstitutionSeTrouver`;

CREATE TABLE `InstitutionSeTrouver` (
  `idInstitutionSeTrouver` bigint(20) NOT NULL auto_increment,
  `matriculeInstitut` char(15) NOT NULL,
  `nomUtilisateur` varchar(15) NOT NULL,
  `motPasse` varchar(150) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `cycleInstitut` varchar(255) default NULL,
  `nomDepartement` varchar(20) NOT NULL, 
  `nomSectionCommunale` varchar(30) NOT NULL,
  `valid` tinyint(1) default NULL,
  `statutI` varchar(7) NULL,
  PRIMARY KEY  (`idInstitutionSeTrouver`),
  UNIQUE KEY `nomUtilisateur` (`nomUtilisateur`),
  KEY `matriculeInstitut` (`matriculeInstitut`),
  KEY `nomDepartement` (`nomDepartement`),
  KEY `nomSectionCommunale` (`nomSectionCommunale`),
  CONSTRAINT `institutionsetrouver_ibfk_1` FOREIGN KEY (`matriculeInstitut`) REFERENCES `Institution` (`matriculeInstitut`),
  CONSTRAINT `institutionsetrouver_ibfk_2` FOREIGN KEY (`nomDepartement`) REFERENCES `Departement` (`nomDepartement`),
  CONSTRAINT `institutionsetrouver_ibfk_3` FOREIGN KEY (`nomSectionCommunale`) REFERENCES `SectionCommunale` (`nomSectionCommunale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `InstitutionSeTrouver` */

/*Table structure for table `Matiere` */

DROP TABLE IF EXISTS `Matiere`;

CREATE TABLE `Matiere` (
  `idMatiere` int(4) NOT NULL auto_increment,
  `codeMatiere` char(6) NOT NULL,
  `libelle` varchar(40) NOT NULL,
  `base` int(4) NOT NULL,
  `nomClasse` varchar(25) NOT NULL,
  `statutMatiere` tinyint(1) NOT NULL,
  PRIMARY KEY  (`idMatiere`),
  UNIQUE KEY  (`codeMatiere`),
  UNIQUE KEY `libelle` (`libelle`),
  KEY `nomClasse` (`nomClasse`),
  CONSTRAINT `matiere_ibfk_1` FOREIGN KEY (`nomClasse`) REFERENCES `Classe` (`nomClasse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Matiere` */

/*Table structure for table `Personnel` */

DROP TABLE IF EXISTS `Personnel`;

CREATE TABLE `Personnel` (
  `idPersonnel` bigint(20) NOT NULL auto_increment,
  `nIF` char(13) NOT NULL,
  `nom` varchar(250) NOT NULL,
  `prenom` varchar(250) NOT NULL,
  `sexe` char(1) NOT NULL,
  `dateNaissance` char(10) NOT NULL,
  `nationalite` varchar(20) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `motDePas` varchar(200) NOT NULL,
  `poste` varchar(255) NOT NULL,
  `fichier` LONGBLOB NOT NULL,
  `valid` tinyint(1) default NULL,
  `statutP` varchar(7) NOT NULL,
  PRIMARY KEY  (`idPersonnel`),
  UNIQUE KEY `nIF` (`nIF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Personnel` */

/*Table structure for table `SectionCommunale` */

DROP TABLE IF EXISTS `SectionCommunale`;

CREATE TABLE `SectionCommunale` (
  `idSectionCommunale` int(4) NOT NULL auto_increment,
  `codePostalSectionCommunale` char(6) NOT NULL,
  `nomSectionCommunale` varchar(30) NOT NULL,
  PRIMARY KEY  (`idSectionCommunale`),
  UNIQUE KEY  (`codePostalSectionCommunale`),
  UNIQUE KEY `nomSectionCommunale` (`nomSectionCommunale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `SectionCommunale` */

/*Table structure for table `SectionCommunaleAppartenir` */

DROP TABLE IF EXISTS `SectionCommunaleAppartenir`;

CREATE TABLE `SectionCommunaleAppartenir` (
  `idSectionCommunaleAppartenir` int(4) NOT NULL auto_increment,
  `nomSectionCommunale` varchar(30) NOT NULL,
  `nomCommune` varchar(30) NOT NULL,
  PRIMARY KEY  (`idSectionCommunaleAppartenir`),
  UNIQUE KEY `idSectionCommunaleAppartenir` (`idSectionCommunaleAppartenir`),
  KEY `nomSectionCommunale` (`nomSectionCommunale`),
  KEY `nomCommune` (`nomCommune`),
  CONSTRAINT `sectioncommunaleappartenir_ibfk_1` FOREIGN KEY (`nomSectionCommunale`) REFERENCES `SectionCommunale` (`nomSectionCommunale`),
  CONSTRAINT `sectioncommunaleappartenir_ibfk_2` FOREIGN KEY (`nomCommune`) REFERENCES `Commune` (`nomCommune`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `SectionCommunaleAppartenir` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
